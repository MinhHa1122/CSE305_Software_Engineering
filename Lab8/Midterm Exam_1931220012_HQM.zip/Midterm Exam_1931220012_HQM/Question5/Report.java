public interface Report {

    void generate() ; 
}
